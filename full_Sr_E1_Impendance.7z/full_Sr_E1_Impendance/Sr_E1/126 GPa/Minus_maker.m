clear all

M=load('126gpa_440K.txt');

L = length(M);

for i=1:L
    M(i,3)=-M(i,3);
end

dlmwrite('126gpa_440K_minus.txt', M);